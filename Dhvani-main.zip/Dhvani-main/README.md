# Dhvani
Team Incognito's latest venture for reducing noise Pollution

So bassically main theme of our product is to reduce noise pollution in non honking areas like schools and hospitals which can cause dangerous mental health issues like tinnitus 
and insomnia.

Workflow:
IOT device will fit in vehicles which will gather frequency of vehicle horn
That frequency will automaticlly stored in csv file through our python code 
And our web UI will Fetch Data From Csv File and Plot Dashboard To monitor Your Activity.
